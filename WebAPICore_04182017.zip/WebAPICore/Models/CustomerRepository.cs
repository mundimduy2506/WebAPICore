﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPICore.Models
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly WebAPIContext _context;

        public CustomerRepository(WebAPIContext context)
        {
            _context = context;

        }

        public IQueryable<Customer> GetCustomers(int pageSize, int pageNumber, string frDate)
        {
            var query = _context.Set<Customer>().Skip((pageNumber - 1) * pageSize).Take(pageSize);

            if (!String.IsNullOrEmpty(frDate))
            {
                try
                {
                    var dateString = "02/16/2008";
                    var dateValue = DateTime.Parse(dateString);
                    var date = DateTime.Parse(frDate);
                    query = query.Where(item => item.EnrolledDate > date);
                }
                catch (Exception ex)
                {

                }
            }

            return query;
        }

        public IQueryable<Customer> GetCustomers()
        {
            return _context.Set<Customer>();
        }

        public void Add(Customer cus)
        {
            _context.Set<Customer>().Add(cus);
            _context.SaveChanges();
        }
    }
}
