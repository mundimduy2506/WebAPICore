﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAPICore.Models;


namespace WebAPICore.Controllers
{
    [Route("api/customer/[action]")]
    public class CustomerController : Controller
    {
        private readonly ICustomerRepository _repo;

        public CustomerController(ICustomerRepository cusRepository)
        {
            _repo = cusRepository;
        }


        // GET: api/customer/getBy?
        [HttpGet]
        [ActionName("")]
        public IEnumerable<Customer> Get(string pageSize, string pageNumber, string frDate)
        {
            var pgSize = String.IsNullOrEmpty(pageSize) ? 15 : Int32.Parse(pageSize);
            var pgNumber = String.IsNullOrEmpty(pageNumber) ? 1 : Int32.Parse(pageNumber);
            return _repo.GetCustomers(pgSize, pgNumber, frDate);
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]Customer cus)
        {
            if (cus == null)
            {
                return BadRequest();
            }

            _repo.Add(cus);

            return CreatedAtRoute("GetTodo", cus);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
