﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPICore.Models
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly WebAPIContext _context;

        public CustomerRepository(WebAPIContext context)
        {
            _context = context;

        }

        public IQueryable<Customer> GetCustomers(int pageSize, int pageNumber, DateTime frDate)
        {
            var query = _context.Set<Customer>().Skip((pageNumber - 1) * pageSize).Take(pageSize);

            if (frDate != null)
            {
                query = query.Where(item => item.EnrolledDate > frDate);
            }

            return query;
        }

        public IQueryable<Customer> GetCustomers()
        {
            return _context.Set<Customer>();
        }

        public void Add(Customer cus)
        {
            _context.Set<Customer>().Add(cus);
            _context.SaveChanges();
        }
    }
}
