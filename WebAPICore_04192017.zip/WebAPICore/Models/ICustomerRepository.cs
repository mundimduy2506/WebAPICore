﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPICore.Models
{
    public interface ICustomerRepository
    {
        IQueryable<Customer> GetCustomers();
        IQueryable<Customer> GetCustomers(int pageSize, int pageNumber, DateTime date);
        void Add(Customer cus);
    }
}
