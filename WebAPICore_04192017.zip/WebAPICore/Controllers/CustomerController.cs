﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAPICore.Models;
using WebAPICore.Response;

namespace WebAPICore.Controllers
{
    [Route("api/customer")]
    public class CustomerController : Controller
    {
        private readonly ICustomerRepository _repo;

        public CustomerController(ICustomerRepository cusRepository)
        {
            _repo = cusRepository;
        }


        // GET: api/customer/{frDate}/
        /// <summary>
        /// Retrieves a list of customers
        /// </summary>
        /// <param name="pageSize">Page size</param>
        /// <param name="pageNumber">Page number</param>
        /// <param name="frDate">From date: mandatory</param>
        /// <returns>List response</returns>
        [HttpGet]
        [Route("{frDate}")]
        public IActionResult Get(string pageSize, string pageNumber, string frDate)
        {
            //If there is difference between ViewModel and Entity, we must create ViewModel folder to manage these classes
            var response = new ListModelResponse<Customer>() as IListModelResponse<Customer>;
            try
            {
                var pgSize = String.IsNullOrEmpty(pageSize) ? 15 : Int32.Parse(pageSize);
                var pgNumber = String.IsNullOrEmpty(pageNumber) ? 1 : Int32.Parse(pageNumber);
                response.PageNumber = pgNumber;
                response.PageSize = pgSize;
                //return 404 is frDate is invalid
                var date = DateTime.Parse(frDate);
                response.Model = _repo.GetCustomers(pgSize, pgNumber, date);
            }
            catch (Exception ex)
            {
                response.DidError = true;
                response.ErrorMessage = "frDate is manadory.";
            }
            return response.ToHttpResponse();
        }

        // GET: api/customer
        /// <summary>
        /// Retrieves all customers
        /// </summary>
        /// <returns>List customers</returns>
        [HttpGet]
        [Route("")]
        public IEnumerable<Customer> Get()
        {
            return _repo.GetCustomers();
        }


    }
}
